<?php
/** Contributor(s): Valmir Carlos Trindade/Translate to Brazilian Portuguese| 03/03/2012 |Curitiba/Paraná/Brasil.|www.ttcasolucoes.com.br **/
$mod_strings = Array (
'CustomerPortal' => 'Portal do Cliente',
'LBL_BASIC_SETTINGS'=>'Configurações Básicas',
'LBL_CUSTOMERPORTAL_SETTINGS'=>'Configurações do Portal do Cliente',
'LBL_ADVANCED_SETTINGS'=>'Configurações Avançadas',
'LBL_MODULE'=>'Módulo',
'LBL_VIEW_ALL_RECORD'=>'Visualizar Todos os Registros Relacionados?',
'LBL_MODULE_INFORMATION'=>'Informação do Módulo',
'LBL_USER_INFORMATION'=>'Informação do Usuário',
'LBL_YES'=>'Sim',
'LBL_NO'=>'Não',
'LBL_USER_DESCRIPTION'=>'O Perfil de Usuário acima selecionado será definido para controle dos campos que aparecem no Portal do Cliente.',
'LBL_GROUP_DESCRIPTION'=>'NOTA : Os Tickets serão Atribuídos ao Responsável acima selecionado pelo Grupo/Usuário padrão do Portal do Cliente.',
'LBL_SELECT_USERS'=>'Selecionar Usuários',
'LBL_DEFAULT_USERS'=>'Responsável Padrão',
'LBL_DISABLE'=>'Desabilitar',
'LBL_ENABLE' =>'Habilitar',
'LBL_MODULE' => 'Módulo',
'LBL_SEQUENCE' =>'Sequência',
'LBL_VISIBLE'=>'Visível'

);

?>
