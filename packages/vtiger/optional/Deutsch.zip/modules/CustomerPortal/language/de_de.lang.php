<?php
/** German translation by crm-now: www.crm-now.de **/
$mod_strings = Array (
'CustomerPortal' => 'Kundenportal',
'LBL_BASIC_SETTINGS'=>'Grundeinstellungen',
'LBL_ADVANCED_SETTINGS'=>'erweiterte Einstellungen',
'LBL_MODULE'=>'Module',
'LBL_VIEW_ALL_RECORD'=>'Alle bezogenen Daten ansehen?',
'YES'=>'Ja',
'NO'=>'Nein',
'LBL_USER_DESCRIPTION'=>'Das oben ausgewählte Nutzerprofil wird genutzt, um zu entscheiden, welche Felder im Kundenportal angezeigt werden
				Sie können die Ansicht von Feldern im Kundenportal ab- oder zuschalten.',
'SELECT_USERS'=>'Nutzer auswählen',				
'LBL_DISABLE'=>'abschalten',
'LBL_ENABLE' =>'zulassen',
'Module' => 'Modul',
'Sequence' =>'Sequenz',
'Visible'=>'sichtbar'

);

?>
