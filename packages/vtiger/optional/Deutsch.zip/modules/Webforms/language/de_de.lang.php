<?php
/**
 * German translation by crm-now [ http://www.crm-now.com ]
 * IMPORTANT: save file with UTF-8 without BOM!
 **/
$mod_strings = Array (
'Webforms' => 'Webforms',
'LBL_SUCCESS' => 'Vielen Dank. Ihre Nachricht wurde empfangen und wird von uns umgehend bearbeitet.',
'LBL_FAILURE' => 'Fehler bei der Übertragung. Bitte noch einmal versuchen.',
'LBL_ERROR_CODE' => 'Fehlercode',
'LBL_ERROR_MESSAGE' => 'Fehlernachricht'
);

?>
