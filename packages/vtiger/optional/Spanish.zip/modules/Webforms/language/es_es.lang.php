<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'Webforms' => 'Webforms',
'LBL_SUCCESS' => 'ha sido añadido a vtiger CRM.',
'LBL_FAILURE' => 'No se ha podido añadir la entrada en vtiger CRM.',
'LBL_ERROR_CODE' => 'Código Error',
'LBL_ERROR_MESSAGE' => 'Mensaje Error'
);

?>
