<?php
/***********************************************************
*  Module       : Installation
*  Language     : Francais
*  Version      : 5.1.0
*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-09-08 17:22:04
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/

$optionalModuleStrings = array(
		'CustomerPortal_description'=>'Interface de paramétrage du plugin Portail Client',
		'FieldFormulas_description'=>'Paramétrage des champs personnalisés avec calculs automatiques',
		'RecycleBin_description'=>'Module pour gérer les enregistrements supprimés, less restaurer ou les effacer définitivement',
		'Tooltip_description'=>'Configurdes infobulles',
		'Webforms_description'=>'Applet serveur pour la configuration de formulaires de capture de leads'
	);
?>