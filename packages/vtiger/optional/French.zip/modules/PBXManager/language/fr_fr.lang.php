<?php
/***********************************************************
*  Module       : PBX Manager
*  Language     : French
*  Version      : 5.4.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr
***********************************************************/

$mod_strings = Array(
	'Asterisk' => 'Asterisk',
	'LBL_ASTERISK_INFORMATION' => 'Information Asterisk',
	'Call From' => 'Appel entrant de',
	'Call To' => 'Appel sortant vers',
	'Time Of Call' => 'Date et heure de l\'appel',
	'PBXManager ID'=>'PBX ID',
);

?>