<?php
/***********************************************************
*  Module       : RecycleBin
*  Language     : Francais
*  Version      : 5.1.0 GA*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-07-21 00:49:17
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/

$mod_strings = Array(
'MSG_EMPTY_RB_CONFIRMATION'=>'Etes vous s�;r de vouloir supprimer d�finitivement tous les enregistrements supprim�s de votre base de donn�es ?',
'LBL_SELECT_MODULE'=>'S�lectionnez un module',
'RecycleBin' => 'Corbeille',
'LBL_EMPTY_MODULE'=>'Aucun enregistrement &agrave; restaurer dans le module',
'LBL_MASS_RESTORE'=>'Restaurer',
'LBL_EMPTY_RECYCLEBIN'=>'Vider la corbeille',
'LNK_RESTORE'=>'restaurer',
'LBL_NO_PERMITTED_MODULES'=>'Vous n\'&ecirc;tes autoris� � modifier aucun module ',
);

?>