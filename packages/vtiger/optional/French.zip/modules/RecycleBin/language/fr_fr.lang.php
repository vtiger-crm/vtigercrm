<?php
/***********************************************************
*  Module       : RecycleBin
*  Language     : French
*  Version      : 5.3.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr

***********************************************************/

$mod_strings = Array(
	'MSG_EMPTY_RB_CONFIRMATION'=>'Etes-vous sûr de vouloir supprimer définitivement tous les enregistrements de la corbeille?',
	'LBL_SELECT_MODULE'=>'Sélectionnez un module',
	'RecycleBin' => 'Corbeille',
	'LBL_EMPTY_MODULE'=>'Aucun enregistrement à restaurer dans le module',
	'LBL_MASS_RESTORE'=>'Restaurer',
	'LBL_EMPTY_RECYCLEBIN'=>'Vider la corbeille',
	'LNK_RESTORE'=>'restaurer',
	'LBL_NO_PERMITTED_MODULES'=>'Vous n\'êtes autorisé à modifier aucun module ',
);

?>