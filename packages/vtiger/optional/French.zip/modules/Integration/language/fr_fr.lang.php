<?php
/***********************************************************
*  Module       : Integration
*  Language     : French
*  Version      : 5.4.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr
***********************************************************/

$mod_strings = Array (
	'Integration' => 'Integration',
	'SINGLE_Integration' => 'Integration',
	'LBL_HOW_TO_USE' => 'Comment l\'utiliser?',
);
?>