<?php
/***********************************************************
*  Module       : Portal
*  Language     : Francais
*  Version      : 5.1.0 GA*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-07-21 00:49:17
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/


$mod_strings = array (
		'LBL_BOOKMARKED_URL' => 'Adresse',
		'LBL_MANAGE_BOOKMARKS' => 'Gérer vos marques pages',
		'LBL_BOOKMARK_LIST' => 'Liste',
		'LBL_MY_BOOKMARKS' => 'Mes marques pages',
		'LBL_NEW_BOOKMARK' => 'Nouveau marque page',
		'LBL_BOOKMARK' => 'Marque page',
		'LBL_NAME' => 'Nom :',
		'LBL_URL' => 'Lien :',
		'LBL_ADD' => 'Ajouter',
		'LBL_SNO' => '#',
		'LBL_BOOKMARK_NAME_URL' => 'Adresse',
		'LBL_TOOLS' => 'Outils',
		'LBL_MANAGE_SITES' => 'Gestion des sites',
		'LBL_MY_SITES' => 'Mes sites',
		'LBL_SET_DEFAULT_BUTTON' => 'Définir par défaut',
);
$mod_list_strings = array (
);
?>