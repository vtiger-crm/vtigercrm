<?php
/***********************************************************
*  Module       : Portal
*  Language     : French
*  Version      : 5.4.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr
***********************************************************/

$mod_strings = array (
	'LBL_BOOKMARKED_URL' => 'Adresse',
	'LBL_MANAGE_BOOKMARKS' => 'Gestion des marques pages',
	'LBL_BOOKMARK_LIST' => 'Liste',
	'LBL_MY_BOOKMARKS' => 'Mes marques pages',
	'LBL_NEW_BOOKMARK' => 'Nouveau marque page',
	'LBL_BOOKMARK' => 'Marque page',
	'LBL_NAME' => 'Nom :',
	'LBL_URL' => 'Lien :',
	'LBL_ADD' => 'Ajouter',
	'LBL_SNO' => '#',
	'LBL_BOOKMARK_NAME_URL' => 'Adresse',
	'LBL_TOOLS' => 'Outils',
	'LBL_MANAGE_SITES' => 'Gestion des sites',
	'LBL_MY_SITES' => 'Mes sites',
	'LBL_SET_DEFAULT_BUTTON' => 'Définir par défaut',
);
$mod_list_strings = array (
);
?>