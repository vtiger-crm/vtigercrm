<?php
/***********************************************************
*  Module       : Help
*  Language     : Francais
*  Version      : 5.1.0 GA*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-07-21 00:49:17
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/

$mod_strings = array(
		'LBL_MODULE_NAME' => 'Comptes',
		'LBL_MODULE_TITLE' => 'Comptes : accueil',
		'LBL_SEARCH_FORM_TITLE' => 'Rechercher comptes',
		'LBL_LIST_FORM_TITLE' => 'Liste comptes',
		'LBL_NEW_FORM_TITLE' => 'Nouveau compte',
		'ERR_DELETE_RECORD' => 'Un numéro d\'enregistrement doit être spécifié pour supprimer ce compte.',
);

?>
