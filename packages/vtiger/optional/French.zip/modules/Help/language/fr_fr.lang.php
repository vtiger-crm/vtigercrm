<?php
/***********************************************************
*  Module       : Help
*  Language     : French
*  Version      : 5.4.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr
***********************************************************/

$mod_strings = array(
		'LBL_MODULE_NAME' => 'Comptes',
		'LBL_MODULE_TITLE' => 'Comptes : accueil',
		'LBL_SEARCH_FORM_TITLE' => 'Rechercher comptes',
		'LBL_LIST_FORM_TITLE' => 'Liste comptes',
		'LBL_NEW_FORM_TITLE' => 'Nouveau compte',
		'ERR_DELETE_RECORD' => 'Un numéro d\'enregistrement doit être spécifié pour supprimer ce compte.',
);

?>
