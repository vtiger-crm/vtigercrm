<?php

/***********************************************************
*  Module       : FieldFormulas
*  Language     : Francais
*  Version      : 5.1.0 GA
*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-07-25 19:37:28
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/

$mod_strings = Array (
'FieldFormulas' => 'Champs',
'LBL_FIELDFORMULAS' => 'Champs personalis&eacute;s',
'LBL_FIELDFORMULAS_DESCRIPTION' => 'Ajoutez une formule personnalis&eacute;e au champs',
'LBL_FIELDS' => 'Champs',
'LBL_FUNCTIONS' => 'Fonctions',
'LBL_FIELD' => 'Champs',
'LBL_EXPRESSION' => 'Expression',
'LBL_SETTINGS' => 'Settings',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'Nouvelle expression de champs',
'LBL_EDIT_EXPRESSION' => 'Editer Expression',
'LBL_MODULE_INFO' => 'Champs avec calcul dans ',
'NEED_TO_ADD_A' =>'Vous devez ajouter une chaine ou un entier ',
'LBL_CUSTOM_FIELD' =>'Choix des Champs'
);

?>
