<?php
/***********************************************************
*  Module       : Tooltips
*  Language     : French
*  Version      : 5.3.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr

***********************************************************/

$mod_strings = Array (
	'Tooltip' => 'Infobulles',
	'LBL_TOOLTIP_MANAGEMENT'=>'Gestion des infobulles',
	'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'Gérer les infobulles',
	'LBL_FIELDS_IN'=>'Champs contenant',
	'LBL_TOOLTIP_HELP_TEXT'=>'Sélectionnez les champs pour lesquels vous voulez ajouter des infobulles',
	'LBL_FIELD'=>'Champs',
);

?>