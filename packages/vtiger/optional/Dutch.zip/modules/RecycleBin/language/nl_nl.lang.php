<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * Vertaling door Weltevree.org  www.weltevree.org
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => 'Prullenbak',
'MSG_EMPTY_RB_CONFIRMATION'=>'Weet u zeker dat u alle gewiste records permanent wilt verwijderen van de database?',
'LBL_SELECT_MODULE'=>'Selecteer Module',
'LBL_EMPTY_MODULE'=>'Geen records gevonden om terug te plaatsen in module',
'LBL_MASS_RESTORE'=>'Terug plaatsen',
'LBL_EMPTY_RECYCLEBIN'=>'Legen Prullenbak',
'LNK_RESTORE'=>'Terug plaatsen',
'LBL_NO_PERMITTED_MODULES'=>'Geen modules met toegang aanwezig',
);

?>
